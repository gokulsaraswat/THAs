// Menu parent children as a diagram...

// Inspired: http://thecodeplayer.com/walkthrough/css3-family-tree

// Author Joëel Lesenne <http://joellesenne.dev>